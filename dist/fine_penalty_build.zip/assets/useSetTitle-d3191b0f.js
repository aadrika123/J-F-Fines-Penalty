import{R as a,d as o,r}from"./index-3c533d21.js";function n(t,e){const{settitleText:s,settitleBarVisibility:i}=a.useContext(o);r.useEffect(()=>{s(t),i(e)},[])}export{n as u};
