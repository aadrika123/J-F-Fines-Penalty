import{j as t}from"./index-b81f09f5.js";import{Q as i}from"./index-9db75e4b.js";function a(e){return t.jsx(i,{value:e==null?void 0:e.url,size:e==null?void 0:e.size})}export{a as Q};
