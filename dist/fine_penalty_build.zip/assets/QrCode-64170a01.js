import{j as t}from"./index-0cbcd253.js";import{Q as i}from"./index-a5a37f66.js";function a(e){return t.jsx(i,{value:e==null?void 0:e.url,size:e==null?void 0:e.size})}export{a as Q};
