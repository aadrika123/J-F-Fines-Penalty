const s="/assets/rmc-c37373e1.png";export{s as r};
