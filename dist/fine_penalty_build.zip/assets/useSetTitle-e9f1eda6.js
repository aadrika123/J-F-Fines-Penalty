import{R as a,c as o,r}from"./index-e38c13c4.js";function n(t,e){const{settitleText:s,settitleBarVisibility:i}=a.useContext(o);r.useEffect(()=>{s(t),i(e)},[])}export{n as u};
