import{j as t}from"./index-3d7803f4.js";import{Q as i}from"./index-7fc0ea0f.js";function a(e){return t.jsx(i,{value:e==null?void 0:e.url,size:e==null?void 0:e.size})}export{a as Q};
