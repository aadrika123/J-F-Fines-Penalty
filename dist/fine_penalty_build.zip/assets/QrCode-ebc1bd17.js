import{j as t}from"./index-56164ba8.js";import{Q as i}from"./index-ed999e4d.js";function a(e){return t.jsx(i,{value:e==null?void 0:e.url,size:e==null?void 0:e.size})}export{a as Q};
