const s="/assets/fp-d655d659.png";export{s as i};
