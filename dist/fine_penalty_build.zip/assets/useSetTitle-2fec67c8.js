import{R as a,d as o,r}from"./index-a77b9889.js";function n(t,e){const{settitleText:s,settitleBarVisibility:i}=a.useContext(o);r.useEffect(()=>{s(t),i(e)},[])}export{n as u};
