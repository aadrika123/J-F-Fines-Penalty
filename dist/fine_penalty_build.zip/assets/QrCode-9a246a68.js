import{j as t}from"./index-78655fd1.js";import{Q as i}from"./index-1c66840c.js";function a(e){return t.jsx(i,{value:e==null?void 0:e.url,size:e==null?void 0:e.size})}export{a as Q};
