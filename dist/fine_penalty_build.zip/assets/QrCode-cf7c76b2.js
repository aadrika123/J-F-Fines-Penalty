import{j as t}from"./index-b6cbcf10.js";import{Q as i}from"./index-7b70f0aa.js";function a(e){return t.jsx(i,{value:e==null?void 0:e.url,size:e==null?void 0:e.size})}export{a as Q};
