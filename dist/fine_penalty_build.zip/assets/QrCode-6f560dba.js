import{j as t}from"./index-e38c13c4.js";import{Q as i}from"./index-38b5d8bb.js";function a(e){return t.jsx(i,{value:e==null?void 0:e.url,size:e==null?void 0:e.size})}export{a as Q};
