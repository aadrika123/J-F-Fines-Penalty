const s="/assets/swachhBharat-876b1398.png";export{s};
