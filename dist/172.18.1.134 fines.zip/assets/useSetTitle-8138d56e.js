import{R as a,c as o,r}from"./index-1c355577.js";function n(t,e){const{settitleText:s,settitleBarVisibility:i}=a.useContext(o);r.useEffect(()=>{s(t),i(e)},[])}export{n as u};
