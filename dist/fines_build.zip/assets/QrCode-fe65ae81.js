import{j as t}from"./index-ce317c0d.js";import{Q as i}from"./index-c53d3051.js";function a(e){return t.jsx(i,{value:e==null?void 0:e.url,size:e==null?void 0:e.size})}export{a as Q};
